#ifndef CMD_H
#define CMD_H

void run_cmd(const char *argv[]);
void show_toast(const char *msg);

#endif