#ifndef OPTIMIZE_H
#define OPTIMIZE_H

void optimize_app(const char *app);

#endif